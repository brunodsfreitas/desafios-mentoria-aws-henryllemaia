declare module 'react-nipple';

declare global {
    interface Window {
        ga: any;
    }
}

window.ga = window.ga || {};
