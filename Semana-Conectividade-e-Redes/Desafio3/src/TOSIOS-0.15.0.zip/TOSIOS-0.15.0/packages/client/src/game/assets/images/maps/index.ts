import dungeon from './dungeon.png';

// This is where you want to reference images needed by your maps
export const SpriteSheets: { [key: string]: string } = {
    'dungeon.png': dungeon,
};
