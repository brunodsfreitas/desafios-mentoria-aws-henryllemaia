import heartEmptyImage from './heart-empty.png';
import heartFullImage from './heart-full.png';
import playerImage from './player.png';
import titleImage from './title.png';

export { heartEmptyImage, heartFullImage, playerImage, titleImage };
