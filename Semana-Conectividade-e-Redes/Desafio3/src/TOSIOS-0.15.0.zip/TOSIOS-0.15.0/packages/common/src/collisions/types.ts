export const COLLISION_TYPES = ['full', 'half'];
export type CollisionType = 'full' | 'half';
