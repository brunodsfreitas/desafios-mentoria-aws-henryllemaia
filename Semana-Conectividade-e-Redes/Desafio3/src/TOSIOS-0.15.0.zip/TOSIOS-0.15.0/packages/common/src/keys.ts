export const UP = ['KeyW', 'KeyZ', 'ArrowUp'];
export const DOWN = ['KeyS', 'ArrowDown'];
export const LEFT = ['KeyA', 'KeyQ', 'ArrowLeft'];
export const RIGHT = ['KeyD', 'ArrowRight'];
export const SHOOT = ['Space'];
export const LEADERBOARD = ['Tab'];
export const MENU = ['Escape'];
