export interface MonsterJSON {
    x: number;
    y: number;
    radius: number;
    rotation: number;
}
