export type PropType = 'potion-red';

export interface PropJSON {
    x: number;
    y: number;
    radius: number;
    active: boolean;
    type: PropType;
}
